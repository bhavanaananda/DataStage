echo "rowlabel,col1,col2,col3,col4" >test-bad-csv.txt
echo "row1,a1,null>\\000<,c1,d1" >>test-bad-csv.txt
