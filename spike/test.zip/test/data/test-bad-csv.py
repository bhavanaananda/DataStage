#f = open("est-bad-csv.txt","w")
print "rowlabel,col1,col2,col3,col4"
print "row1,a1,null>\x00<,c1,d1"
